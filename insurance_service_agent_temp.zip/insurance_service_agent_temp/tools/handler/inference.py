import json
import os
import logging
import requests
import time
from typing import Optional, Dict, Any
from base.userinfo_memory import user_info_cache

# Configure logger
logger = logging.getLogger(__name__)

# ---------------------------------------------------------
# STATEFUL MOCK DATABASE
# ---------------------------------------------------------
# This dictionary will persist in memory while the server is running.
_POLICY_DB = {
    "P-12345": {
        "policy_number": "P-12345",
        "status": "Active",
        "insured_name": "Acme Corp",
        "address": "100 Old St, Metropolis, NY",
        "effective_date": "2025-01-01",
        "expiration_date": "2026-01-01"
    },
    "P-99999": {
        "policy_number": "P-99999",
        "status": "Cancelled",
        "insured_name": "Jane Doe",
        "address": "404 Not Found Ln",
        "cancellation_date": "2024-12-31"
    },
    "P-88888": {
        "policy_number": "P-88888",
        "status": "Active",
        "insured_name": "H&M",
        "address": "2LA, Second Street, LA",
        "effective_date": "2025-01-01",
        "expiration_date": "2026-01-01"
    }
}

def retrieve_policy_details(policy_number: str) -> str:
    """
    Retrieves the current status and details of an insurance policy from the backend API.
    """
    logger.info(f"[POLICY RETRIEVAL] Fetching details for {policy_number}")
    
    # Configuration (In production, these come from os.environ)
    base_url = os.getenv("POLICY_API_BASE_URL", "https://api.example-insurer.com/v1")
    api_key = os.getenv("POLICY_API_KEY", "mock-key")
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    try:
        # Simulate API call: In a real scenario, uncomment the following lines:
        # response = requests.get(f"{base_url}/policies/{policy_number}", headers=headers)
        # response.raise_for_status()
        # return json.dumps(response.json())

        # ---------------------------------------------------------
        # STATEFUL MOCK FALLBACK
        # ---------------------------------------------------------
        if policy_number in _POLICY_DB:
            return json.dumps(_POLICY_DB[policy_number])
        else:
             return json.dumps({"error": "Policy not found"})

    except requests.exceptions.RequestException as e:
        logger.error(f"[POLICY RETRIEVAL] API Error: {str(e)}")
        return json.dumps({"error": f"Failed to retrieve policy: {str(e)}"})


def update_policy_address(policy_number: str, new_address: str, effective_date: str = None) -> str:
    """
    Updates the address for a policy via the backend API.
    """
    logger.info(f"[POLICY UPDATE] Updating address for {policy_number} to {new_address}")

    base_url = os.getenv("POLICY_API_BASE_URL", "https://api.example-insurer.com/v1")
    api_key = os.getenv("POLICY_API_KEY", "mock-key")
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "new_address": new_address,
        "effective_date": effective_date or "IMMEDIATE"
    }

    try:
        # Simulate API call
        # response = requests.post(f"{base_url}/policies/{policy_number}/endorsements", headers=headers, json=payload)
        # response.raise_for_status()
        # return json.dumps(response.json())

        # ---------------------------------------------------------
        # STATEFUL MOCK FALLBACK
        # ---------------------------------------------------------
        if policy_number in _POLICY_DB:
            # Update the in-memory state
            _POLICY_DB[policy_number]["address"] = new_address
            if effective_date:
                _POLICY_DB[policy_number]["effective_date"] = effective_date
            
            endorsement_id = f"END-{hash(policy_number + new_address) % 10000}"
            return json.dumps({
                "status": "Success",
                "message": f"Address for {policy_number} updated to {new_address}.",
                "endorsement_id": endorsement_id,
                "effective_date": effective_date or "Today"
            })
        else:
            return json.dumps({"error": "Policy not found"})

    except requests.exceptions.RequestException as e:
        logger.error(f"[POLICY UPDATE] API Error: {str(e)}")
        return json.dumps({"error": f"Failed to update address: {str(e)}"})

def faq_inference(message: str, memory: str, request_id: str, form_code: str) -> str:
    """
    Calls inference -> FAQ / Coverage inference.
    Logs timings and returns the inference response decorated with <answer></answer>.
    """
    print("\n===================================================================")
    print("\n",form_code)
    print("\n===================================================================")
    logger.warning(f"Before tool run (ms): {int(time.time() * 1000)}")
    overall_start = time.time()

    # ------------------------------
    # 1. Prepare user message
    # ------------------------------
    user_info = user_info_cache.get(request_id)
    user_msg = f"#memory:{memory}\n#usermessage:{message}\nformCode: {form_code}"
    logger.warning(f"Memory: {memory}")
    logger.warning(f"FAQ Inference Request JSON: {user_msg}")

    # ------------------------------
    # 2. Build inference payload
    # ------------------------------
    payload = {
        "user_msg": user_msg,
        "user_id": user_info.get("user_id"),
        "intent": "coverage_query_inference",
        "session_id": user_info.get("session_id"),
        "request_id": user_info.get("request_id"),
        "user_name": user_info.get("user_name"),
        "version_id": os.getenv("VERSION_ID"),
        "default": os.getenv("DEFAULT"),
        "latest": os.getenv("DEFAULT"),
        "entity": os.getenv("ENTITY"),
        "image_input": [{"type": os.getenv("IMAGE_TYPE"), "url": os.getenv("IMAGE_URL")}],
        "agent_code": os.getenv("AGENT_CODE"),
        "context_list": [{
            "context_type": "perception",
            "context_name": "perception_usermessage",
            "context_value": user_msg
        }],
        "top": os.getenv("TOP"),
        "validation_clue": os.getenv("VALIDATION_CLUE"),
        "model": os.getenv("MODEL"),
        "context_code": os.getenv("CONTEXT_CODE")
    }
    # ------------------------------
    # 3. Call the API
    # ------------------------------
    url = os.getenv("FAQ_URL")
    headers = {"Content-Type": "application/json"}

    start_time = time.time()
    response = requests.post(url, headers=headers, data=json.dumps(payload))
    end_time = time.time()

    duration_seconds = end_time - start_time
    logger.warning(f"[INVOKE INFERENCE] RUN ENDED in {duration_seconds}")

    # Return API response as JSON
    return json.dumps(response.json())

# =========================================================
# EXCEPTIONS
# =========================================================

class APIProxyRequestError(Exception):
    pass


class APIProxyResponseError(Exception):
    pass


# =========================================================
# API CLIENT
# =========================================================

class APIProxyClient:

    def __init__(self, base_url: str, timeout: int = 30):

        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.trust_env = False

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> requests.Response:

        url = f"{self.base_url}/{endpoint.lstrip('/')}"

        try:

            response = self.session.request(
                method=method.upper(),
                url=url,
                params=params,
                json=json_data,
                headers=headers,
                timeout=self.timeout,
            )

        except requests.RequestException as e:
            raise APIProxyRequestError(str(e)) from e

        if not response.ok:
            raise APIProxyResponseError(
                f"API returned {response.status_code}: {response.text}"
            )

        return response

    def get(self, endpoint: str, **kwargs):
        return self.request("GET", endpoint, **kwargs)

    def put(self, endpoint: str, **kwargs):
        return self.request("PUT", endpoint, **kwargs)


# =========================================================
# API CLIENT INITIALIZATION
# =========================================================

BASE_URL = os.getenv("INSTANDA_POLICY_API_BASE_URL")

client = APIProxyClient(base_url=BASE_URL)

RETRIEVE_BASE_URL = os.getenv("INSTANDA_DB_BASE_URL")

retrieve_client = APIProxyClient(base_url=RETRIEVE_BASE_URL)
# =========================================================
# TOOL 1: GET Current User
# =========================================================
def get_current_user(request_id: str) -> Optional[Dict[str, str]]:
    user_info = user_info_cache.get(request_id)
    if not user_info:
        return None  

    return {
        "user_email": user_info.get("user_name"),
        "provider": os.getenv("PROVIDER")
    }
# =========================================================
# TOOL 2: GET POLICY DETAILS
# =========================================================

def get_policy_details(policy_number: str) -> str:
    """
    Retrieve policy details from Instanda API
    """
    try:

        response = client.get(
        f"/policies/{policy_number}"
        )
        return json.dumps({
            "status": "success",
            "policy_number": policy_number,
            "data": response.json()
        })

    except Exception as e:

        return json.dumps({
            "status": "error",
            "message": str(e)
        })


# =========================================================
# TOOL 3: UPDATE POLICY FIELDS
# =========================================================

def update_policy_fields(
    policy_number: str,
    fields: Dict[str, Any]
) -> str:
    """
    Update policy fields in Instanda
    Fields can vary dynamically
    """

    payload = {
        "fields": fields
    }

    try:

        response = client.put(
            f"/policies/{policy_number}",
            json_data=payload
        )

        return json.dumps({
            "status": "success",
            "policy_number": policy_number,
            "updated_fields": fields,
            "response": response.json()
        })

    except Exception as e:

        return json.dumps({
            "status": "error",
            "message": str(e)
        })
    
# =========================================================
# TOOL 4: RETRIEVE POLICY ID BY EMAIL
# =========================================================

def retrieve_policy_id(email: str) -> str:

    try:
        response = retrieve_client.get(
        "/instanda/public/policyId",
        params={"email": email}
        )

        return json.dumps({
            "status": "success",
            "email": email,
            "data": response.json()
        })

    except Exception as e:
        return json.dumps({
            "status": "error",
            "message": str(e)
        })
# =========================================================
# TOOL 5: Policy Inference
# =========================================================
def policy_inference(question: str) -> str:
    """
    Calls Policy Semantic Search API.
    Logs timings and returns the API response as JSON string.
    """

    print("\n===============================================================")
    print(f"\n inside Policy Inference")
    print("===============================================================\n")

    logger.warning(f"[POLICY] Before API call (ms): {int(time.time() * 1000)}")
    overall_start = time.time()

    # ------------------------------
    # 1. Build payload
    # ------------------------------
    payload = {
        "policy_id": "P-12345",
        "question": question
    }

    logger.warning(f"[POLICY] Request Payload: {json.dumps(payload)}")

    # ------------------------------
    # 2. Call API
    # ------------------------------
    url = "http://127.0.0.1:8000/semantic-search"
    headers = {"Content-Type": "application/json"}

    try:
        start_time = time.time()

        response = requests.post(
            url,
            headers=headers,
            data=json.dumps(payload)
        )

        end_time = time.time()
        duration_seconds = end_time - start_time

        logger.warning(f"[POLICY] API call completed in {duration_seconds:.3f}s")

        # ------------------------------
        # 3. Handle response
        # ------------------------------
        response.raise_for_status()  # raises error for 4xx/5xx

        result = response.json()

        logger.warning(f"[POLICY] Response: {result}")
        print("\n===================================================================")
        print(json.dumps(response.json()))
        print("\n===================================================================")
        return json.dumps(result)

    except requests.exceptions.RequestException as e:
        logger.error(f"[POLICY] API call failed: {str(e)}")

        return json.dumps({
            "error": "Policy inference failed",
            "details": str(e)
        })

    finally:
        overall_end = time.time()
        logger.warning(f"[POLICY] Total execution time: {overall_end - overall_start:.3f}s")

# Map tools for registration
TOOLS = [
    retrieve_policy_details,
    update_policy_address,
    faq_inference,
    get_policy_details,
    update_policy_fields,
    retrieve_policy_id,
    get_current_user,
    policy_inference
]
