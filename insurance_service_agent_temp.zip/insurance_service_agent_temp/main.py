import uvicorn
import os
from core.startup import  create_app_tools
from dotenv import load_dotenv 
#from middlewares.goal_setting_middleware import goal_setting_middleware
#from middlewares.procedure_enhancement_middleware import procedure_enhancement_middleware
#from middlewares.procedure_enhancement_fileprompt_middleware import procedure_enhancement_fileprompt_middleware
from middlewares.agent_metric_middleware import agent_metric_middleware
from middlewares.personalization_middleware import personalizaation_middleware
#from middlewares.rbac_middelware import rbac_middleware
#from middlewares.cost_policy_middleware import cost_policy_middleware
from middlewares.cleanup_middleware import cleanup_middleware



load_dotenv()

from tools.handler.inference import TOOLS

# Middlewares execute in order you have configured:
middlewares = [
    agent_metric_middleware,
    #goal_setting_middleware,  
    #rbac_middleware,
    personalizaation_middleware,
    # cost_policy_middleware,
	cleanup_middleware  
    # procedure_enhancement_middleware
]

# Entry point
if __name__ == "__main__":
    app = create_app_tools(middlewares=middlewares, tools=TOOLS)
    uvicorn.run(app, host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "8086")))
