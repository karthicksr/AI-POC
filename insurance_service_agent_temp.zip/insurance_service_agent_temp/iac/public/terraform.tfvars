# ---------------- ACR ----------------
acr_name           = "digitalagentacr"
acr_login_server   = "digitalagentacr.azurecr.io"

# ---------------- Common ----------------
location             = "westus2"
cg_name              = "insurance-service-agent-public"
restart_policy       = "Always"
tags                 = {}
dns_label            = "insurance-service-agent-public"
# ---------------- attributeextractor ----------------
container_name        = "insurance-service-agent"
acr_repo              = "insurance_service_agent"
container_cpu         = 1
container_memory      = 0.5
container_port        = 8089
env                   = { ENV = "dev" }