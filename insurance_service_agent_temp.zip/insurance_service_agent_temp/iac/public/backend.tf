terraform {
  backend "azurerm" {
    resource_group_name  = "tcig-coe"
    storage_account_name = "tfstatestoragedigitalagt"
    container_name       = "tfstate"                  
    key                  = "insurance-service-agent.tfstate"
  }     
}