terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.0"
    }
  }
}

provider "azurerm" {
  features {}
}

#EXISTING AZURE RESOURCES

data "azurerm_resource_group" "rg" {
  name = "tcig-coe"
}

data "azurerm_user_assigned_identity" "aci_uami" {
  name                = "aci-uami-foundry-attributeextractor-public"
  resource_group_name = data.azurerm_resource_group.rg.name
}

data "azurerm_container_registry" "acr" {
  name                = var.acr_name
  resource_group_name = data.azurerm_resource_group.rg.name
}

#CONTAINER GROUP (ACI)

resource "azurerm_container_group" "aci" {
  name                = var.cg_name
  location            = var.location
  resource_group_name = data.azurerm_resource_group.rg.name
  ip_address_type     = "Public"
  os_type             = "Linux"
  restart_policy      = var.restart_policy
  dns_name_label      = var.dns_label

  identity {
    type         = "UserAssigned"
    identity_ids = [data.azurerm_user_assigned_identity.aci_uami.id]
  }

  image_registry_credential {
    server   = var.acr_login_server
    user_assigned_identity_id = data.azurerm_user_assigned_identity.aci_uami.id
  }

  container {
    name   = var.container_name
    image  = "${var.acr_login_server}/${var.acr_repo}:${var.image_tag}"
    cpu    = var.container_cpu
    memory = var.container_memory
    environment_variables = var.env

    ports {
      port     = var.container_port
      protocol = "TCP"
    }
  }

}
