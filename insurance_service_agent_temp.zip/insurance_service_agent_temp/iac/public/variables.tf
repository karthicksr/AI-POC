variable "acr_name" {
  type = string
}


variable "acr_login_server" {
  type = string
}


variable "location" {
  type = string
}

variable "cg_name" {
  type = string
}

variable "dns_label" {
  type = string
}

# ---------------- Remote Agent(discount-agent) ----------------
variable "container_name" {
  type = string
}

variable "acr_repo" {
  type = string
}

variable "image_tag" {
  type     = string
  default  = "latest"
}

variable "container_cpu" {
  type = number
}

variable "container_memory" {
  type = number
}

variable "container_port" {
  type = number
}

variable "env" {
  type = map(string)
}

variable "restart_policy" {
  type = string
}

variable "tags" {
  type = map(string)
}
